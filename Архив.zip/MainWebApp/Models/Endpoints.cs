﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MainWebApp.Models
{
    public class Endpoints
    {
        public string FeedbackEndpoint { get; set; }
        public string ForumEndpoint { get; set; }
    }
}
